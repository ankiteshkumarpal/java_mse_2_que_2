-- Student Profile and Skill Development Management System
-- Q2: MySQL database and queries (MSE-2)
-- Run this script in MySQL Workbench.

CREATE DATABASE IF NOT EXISTS student_skill_db;
USE student_skill_db;

-- Main student table. Student ID is the primary key, so duplicates are prevented.
CREATE TABLE IF NOT EXISTS students (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
    email_address VARCHAR(150) NOT NULL UNIQUE,
    course_name VARCHAR(100) NOT NULL,
    programming_score DECIMAL(5,2) NOT NULL,
    mathematics_score DECIMAL(5,2) NOT NULL,
    CONSTRAINT chk_programming_score CHECK (programming_score BETWEEN 0 AND 100),
    CONSTRAINT chk_mathematics_score CHECK (mathematics_score BETWEEN 0 AND 100)
);

-- Separate table stores multiple technical skills for each student.
CREATE TABLE IF NOT EXISTS student_skills (
    skill_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    skill_name VARCHAR(80) NOT NULL,
    CONSTRAINT fk_student_skills_student
        FOREIGN KEY (student_id) REFERENCES students(student_id)
        ON DELETE CASCADE,
    CONSTRAINT uq_student_skill UNIQUE (student_id, skill_name)
);

-- Sample data. Re-running the script does not create duplicate sample IDs.
INSERT INTO students
(student_id, student_name, email_address, course_name, programming_score, mathematics_score)
VALUES
(101, 'Amit', 'amit@example.com', 'B.Tech CSIT', 88.50, 92.00),
(102, 'Neha', 'neha@example.com', 'B.Tech CSE', 76.00, 68.00),
(103, 'Rahul', 'rahul@example.com', 'B.Tech IT', 42.00, 81.00),
(104, 'Priya', 'priya@example.com', 'B.Tech CSIT', 55.00, 60.00),
(105, 'Karan', 'karan@example.com', 'B.Tech CSE', 95.00, 90.00)
ON DUPLICATE KEY UPDATE
student_name = VALUES(student_name),
course_name = VALUES(course_name),
programming_score = VALUES(programming_score),
mathematics_score = VALUES(mathematics_score);

INSERT IGNORE INTO student_skills (student_id, skill_name) VALUES
(101, 'Java'), (101, 'Spring Boot'), (101, 'MySQL'),
(102, 'Python'), (102, 'SQL'),
(103, 'Java'), (103, 'MySQL'),
(104, 'HTML'), (104, 'CSS'),
(105, 'Java'), (105, 'Spring Boot'), (105, 'MySQL');

-- 1. Calculate each student's average score.
SELECT student_id, student_name,
       ROUND((programming_score + mathematics_score) / 2, 2) AS average_score
FROM students;

-- 2. Assign performance category based on average score.
SELECT student_id, student_name,
       ROUND((programming_score + mathematics_score) / 2, 2) AS average_score,
       CASE
           WHEN (programming_score + mathematics_score) / 2 >= 85 THEN 'Excellent'
           WHEN (programming_score + mathematics_score) / 2 >= 70 THEN 'Good'
           WHEN (programming_score + mathematics_score) / 2 >= 50 THEN 'Satisfactory'
           ELSE 'Needs Improvement'
       END AS performance_category
FROM students;

-- 3. Identify the stronger subject for each student.
SELECT student_id, student_name,
       CASE
           WHEN programming_score > mathematics_score THEN 'Programming'
           WHEN mathematics_score > programming_score THEN 'Mathematics'
           ELSE 'Both are equal'
       END AS stronger_subject
FROM students;

-- 4a. Search student by ID (change 101 as needed).
SELECT * FROM students WHERE student_id = 101;

-- 4b. Search student by email (change email as needed).
SELECT * FROM students WHERE email_address = 'amit@example.com';

-- 4c. Search students by course (change course as needed).
SELECT * FROM students WHERE course_name = 'B.Tech CSIT';

-- 5. Generate merit list: highest average score first.
SELECT student_id, student_name,
       ROUND((programming_score + mathematics_score) / 2, 2) AS average_score
FROM students
ORDER BY average_score DESC, student_id ASC;

-- 6. Identify students who have the same technical skills.
-- This compares students with identical complete skill sets.
SELECT s1.student_id AS student_1_id, s1.student_name AS student_1,
       s2.student_id AS student_2_id, s2.student_name AS student_2
FROM students s1
JOIN students s2 ON s1.student_id < s2.student_id
WHERE NOT EXISTS (
    SELECT skill_name FROM student_skills WHERE student_id = s1.student_id
    EXCEPT
    SELECT skill_name FROM student_skills WHERE student_id = s2.student_id
)
AND NOT EXISTS (
    SELECT skill_name FROM student_skills WHERE student_id = s2.student_id
    EXCEPT
    SELECT skill_name FROM student_skills WHERE student_id = s1.student_id
);

-- MySQL versions before 8.0.31 may not support EXCEPT.
-- Portable alternative for MySQL 8.0: same skill sets using counts and matching.
-- This query returns pairs with the same set of skills.
SELECT a.student_id AS student_1_id, b.student_id AS student_2_id
FROM students a
JOIN students b ON a.student_id < b.student_id
WHERE
    (SELECT COUNT(*) FROM student_skills x WHERE x.student_id = a.student_id) =
    (SELECT COUNT(*) FROM student_skills y WHERE y.student_id = b.student_id)
    AND NOT EXISTS (
        SELECT 1
        FROM student_skills x
        WHERE x.student_id = a.student_id
          AND NOT EXISTS (
              SELECT 1 FROM student_skills y
              WHERE y.student_id = b.student_id
                AND y.skill_name = x.skill_name
          )
    );

-- 7. Students needing improvement in programming but mathematics >= 75.
-- "Needs improvement in programming" is interpreted as programming score below 50.
SELECT student_id, student_name, programming_score, mathematics_score
FROM students
WHERE programming_score < 50
  AND mathematics_score >= 75;

-- 8. Demonstrate score validation (valid insert).
-- Uncomment and change ID/email if you want to test a new record.
-- INSERT INTO students VALUES (106, 'Test Student', 'test@example.com',
--                             'B.Tech CSIT', 70, 80);

-- To test duplicate ID prevention, try inserting an existing student_id.
-- It will fail with a duplicate primary-key error.
-- INSERT INTO students VALUES (101, 'Duplicate', 'duplicate@example.com',
--                             'B.Tech CSIT', 70, 80);

-- To test score validation, try a score outside 0-100.
-- With CHECK constraints enforced, this insert is rejected.
-- INSERT INTO students VALUES (107, 'Invalid', 'invalid@example.com',
--                             'B.Tech CSIT', 110, 80);

-- View student details along with their technical skills.
SELECT s.student_id, s.student_name, s.email_address, s.course_name,
       s.programming_score, s.mathematics_score,
       GROUP_CONCAT(sk.skill_name ORDER BY sk.skill_name SEPARATOR ', ') AS technical_skills
FROM students s
LEFT JOIN student_skills sk ON s.student_id = sk.student_id
GROUP BY s.student_id, s.student_name, s.email_address, s.course_name,
         s.programming_score, s.mathematics_score
ORDER BY s.student_id;
