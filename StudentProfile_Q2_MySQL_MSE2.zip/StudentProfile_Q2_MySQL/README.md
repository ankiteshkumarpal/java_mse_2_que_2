# Q2 – Student Profile and Skill Development Management System (MySQL)

This project implements Q2 from the uploaded CS336B MSE-2 paper.

## Files
- `sql/student_profile_q2.sql` – creates the database and tables, inserts sample data, and provides queries for all eight requirements.
- `README.md` – setup and run instructions.

## Run using MySQL Workbench
1. Open MySQL Workbench and connect to your local MySQL server.
2. Open `sql/student_profile_q2.sql`.
3. Click the lightning bolt **Execute** button to run the full script.
4. The database `student_skill_db` will be created.
5. Run individual SELECT queries again as needed to inspect their result grids.

## Tables
- `students`: student profile and two subject scores.
- `student_skills`: one row per technical skill, linked to `students` with a foreign key.

## Requirements covered
1. Average score: average of programming and mathematics.
2. Performance category: Excellent (>=85), Good (70–84.99), Satisfactory (50–69.99), Needs Improvement (<50).
3. Stronger subject: compares programming and mathematics scores.
4. Search by student ID, email, or course.
5. Merit list sorted by average descending.
6. Find students with identical complete technical-skill sets. A MySQL 8-compatible query is provided.
7. Programming score below 50 and mathematics score at least 75. The paper does not define a numeric programming threshold; below 50 is used as a clear assumption.
8. Duplicate IDs prevented by PRIMARY KEY; email duplicates prevented by UNIQUE; scores restricted to 0–100 with CHECK constraints.

## Important compatibility note
The script includes a first version of the same-skill query using `EXCEPT`, which is supported in MySQL 8.0.31+ only. If your MySQL version is older, skip that first query and run the portable `NOT EXISTS` query immediately below it. The portable query is intended for MySQL 8.0.

## Resetting sample data
The script uses `CREATE DATABASE IF NOT EXISTS` and upsert/ignore inserts. Re-running it will not duplicate the sample records or skill rows.
