package com.example.studentprofile.repository;

import com.example.studentprofile.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface StudentRepository extends JpaRepository<Student, Integer> {
    List<Student> findAllByOrderByProgrammingScoreDesc();
    boolean existsByEmailAddress(String emailAddress);
}
