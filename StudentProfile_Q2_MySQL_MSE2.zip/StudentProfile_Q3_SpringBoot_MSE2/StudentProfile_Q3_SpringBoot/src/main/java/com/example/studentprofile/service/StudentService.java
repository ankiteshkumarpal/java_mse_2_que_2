package com.example.studentprofile.service;

import com.example.studentprofile.model.Student;
import com.example.studentprofile.repository.StudentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Comparator;
import java.util.List;

@Service
public class StudentService {

    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public Student addStudent(Student student) {
        if (repository.existsById(student.getStudentId())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Student ID already exists: " + student.getStudentId());
        }
        if (repository.existsByEmailAddress(student.getEmailAddress())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Email already exists: " + student.getEmailAddress());
        }
        return repository.save(student);
    }

    public List<Student> getAllStudents() {
        return repository.findAll();
    }

    public Student getStudentById(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Student not found with ID: " + id));
    }

    public Student updateStudentScoresAndSkills(Integer id, Student updated) {
        Student existing = getStudentById(id);
        existing.setProgrammingScore(updated.getProgrammingScore());
        existing.setMathematicsScore(updated.getMathematicsScore());
        existing.setTechnicalSkills(updated.getTechnicalSkills());
        return repository.save(existing);
    }

    public void deleteStudent(Integer id) {
        Student existing = getStudentById(id);
        repository.delete(existing);
    }

    public List<Student> getMeritList() {
        return repository.findAll().stream()
                .sorted(Comparator.comparingDouble(Student::getAverageScore).reversed()
                        .thenComparing(Student::getStudentId))
                .toList();
    }
}
