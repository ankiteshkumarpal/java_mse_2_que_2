# Q3 – Student Profile REST API (Spring Boot + MySQL)

This project implements the six Q3 requirements from the CS336B MSE-2 paper:
1. Add a student.
2. Retrieve all students.
3. Search for a student by ID.
4. Update student scores and technical skills.
5. Delete a student record.
6. Display the merit list.

## Maven dependencies included
- Spring Boot Starter Web
- Spring Boot Starter Data JPA
- MySQL Connector/J
- Spring Boot Starter Validation
- Spring Boot Starter Test

Maven downloads dependencies automatically on the first build. The ZIP contains the complete Maven source project and `pom.xml`, not a pre-downloaded Maven repository.

## Before running
1. Make sure MySQL Server is running.
2. Open `src/main/resources/application.properties`.
3. Replace `YOUR_MYSQL_PASSWORD` with your actual MySQL root password.
4. The project connects to database `student_skill_db`, created by Q2. The URL also allows MySQL to create it if it does not exist.
5. The app uses Hibernate `ddl-auto=update` to create/update the `students` and `student_skills` tables. It does not delete existing data.

## Run in VS Code terminal
Open the folder containing `pom.xml`, then run:

```powershell
mvn clean
mvn spring-boot:run
```

Wait until the terminal says the application has started and Tomcat is running on port 8080. Keep this terminal open while testing Postman.

## Postman endpoints
Base URL: `http://localhost:8080/api/students`

### 1. Add a student
Method: POST  
URL: `http://localhost:8080/api/students`  
Body → raw → JSON:

```json
{
  "studentId": 201,
  "studentName": "Ankit",
  "emailAddress": "ankit201@example.com",
  "courseName": "B.Tech CSIT",
  "programmingScore": 86,
  "mathematicsScore": 91,
  "technicalSkills": ["Java", "Spring Boot", "MySQL"]
}
```

Expected status: `201 Created`.

### 2. Retrieve all students
Method: GET  
URL: `http://localhost:8080/api/students`

### 3. Search by student ID
Method: GET  
URL: `http://localhost:8080/api/students/201`

### 4. Update scores and skills
Method: PUT  
URL: `http://localhost:8080/api/students/201`  
Body → raw → JSON:

```json
{
  "programmingScore": 92,
  "mathematicsScore": 95,
  "technicalSkills": ["Java", "Spring Boot", "REST API", "MySQL"]
}
```

Only scores and skills are updated. Name, email, and course remain unchanged.

### 5. Delete a student
Method: DELETE  
URL: `http://localhost:8080/api/students/201`

### 6. Display merit list
Method: GET  
URL: `http://localhost:8080/api/students/merit-list`

The merit list is sorted by average score (programming + mathematics) / 2, highest first. Each response includes average score and performance category.

## Important notes
- Student ID is the primary key.
- Email is unique.
- Programming and mathematics scores are validated from 0 to 100.
- Duplicate IDs/emails return HTTP 409 Conflict.
- Missing student IDs return HTTP 404 Not Found.
- Validation failures return HTTP 400 Bad Request.
- `technicalSkills` is stored in a separate `student_skills` table using JPA `@ElementCollection`.
- Merit list uses Java Stream sorting and the average-score business logic.
- This API uses the existing `student_skill_db` from Q2. It is okay if Q2 sample records are already present; use new IDs and email addresses for Q3 testing.
