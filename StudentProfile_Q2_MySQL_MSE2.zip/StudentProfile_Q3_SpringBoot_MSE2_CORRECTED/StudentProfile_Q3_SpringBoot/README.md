# Q3 – Student Profile REST API (Spring Boot + MySQL)

This project implements the six Q3 requirements from the CS336B MSE-2 paper:
1. Add a student.
2. Retrieve all students.
3. Search for a student by ID.
4. Update student scores and skills.
5. Delete a student record.
6. Display the merit list.

## Maven dependencies
- Spring Boot Starter Web
- Spring Boot Starter Data JPA
- MySQL Connector/J
- Spring Boot Starter Validation
- Spring Boot Starter Test

Maven downloads the dependencies automatically. The project includes `.mvn/settings.xml`, configured to use Google's Maven Central mirror as an alternative when Maven Central returns HTTP 429.

## Before running
1. Make sure MySQL Server is running.
2. Open `src/main/resources/application.properties`.
3. Replace `YOUR_MYSQL_PASSWORD` with your actual MySQL root password.
4. The project connects to database `student_skill_db` created in Q2.
5. Hibernate `ddl-auto=update` creates/updates the required tables without dropping existing data.

## Build and run (PowerShell, from the folder containing pom.xml)
Use the project-local mirror settings:

```powershell
mvn -s .mvn/settings.xml clean install
mvn -s .mvn/settings.xml spring-boot:run
```

If the mirror is unavailable in your network, retry later or use your normal `mvn clean install` command. Maven dependencies are not bundled inside the ZIP.

Keep the terminal running while testing Postman. The server uses port 8080.

## Postman endpoints
Base URL: `http://localhost:8080/api/students`

### 1. Add a student
POST `http://localhost:8080/api/students`

Body → raw → JSON:
```json
{
  "studentId": 201,
  "studentName": "Ankit",
  "emailAddress": "ankit201@example.com",
  "courseName": "B.Tech CSIT",
  "programmingScore": 86,
  "mathematicsScore": 91,
  "technicalSkills": ["Java", "Spring Boot", "MySQL"]
}
```
Expected: `201 Created`.

### 2. Retrieve all students
GET `http://localhost:8080/api/students`

### 3. Search for a student by ID
GET `http://localhost:8080/api/students/201`

### 4. Update student scores and skills
PUT `http://localhost:8080/api/students/201`

Body → raw → JSON:
```json
{
  "programmingScore": 92,
  "mathematicsScore": 95,
  "technicalSkills": ["Java", "Spring Boot", "REST API", "MySQL"]
}
```
Only scores and skills are updated; name, email, and course remain unchanged.

### 5. Delete a student
DELETE `http://localhost:8080/api/students/201`

### 6. Display merit list
GET `http://localhost:8080/api/students/merit-list`

The merit list is sorted by average score (programming + mathematics) / 2, highest first. Student responses include calculated average score and performance category.

## Validation and business rules
- Student ID is the primary key.
- Email address is unique.
- Programming and mathematics scores must be between 0 and 100.
- Duplicate IDs/emails return HTTP 409 Conflict.
- Missing student IDs return HTTP 404 Not Found.
- Invalid request fields return HTTP 400 Bad Request.
- Technical skills are stored in the `student_skills` table using JPA `@ElementCollection`.
- Merit list sorting uses Java Stream operations.

## Existing Q2 database
The project is designed to use the `student_skill_db` database from Q2. Existing Q2 student records are preserved. For Postman testing, use a new student ID and email address, such as ID `201` and `ankit201@example.com`.
