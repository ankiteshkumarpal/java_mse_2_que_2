package com.example.studentprofile.controller;

import com.example.studentprofile.model.Student;\nimport com.example.studentprofile.dto.StudentUpdateRequest;
import com.example.studentprofile.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    // 1. Add a student
    @PostMapping
    public ResponseEntity<Student> addStudent(@Valid @RequestBody Student student) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.addStudent(student));
    }

    // 2. Retrieve all students
    @GetMapping
    public List<Student> getAllStudents() {
        return service.getAllStudents();
    }

    // 3. Search for a student by ID
    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable Integer id) {
        return service.getStudentById(id);
    }

    // 4. Update student scores and technical skills
    @PutMapping("/{id}")
    public Student updateScoresAndSkills(
            @PathVariable Integer id,
            @Valid @RequestBody StudentUpdateRequest updatedStudent) {
        return service.updateStudentScoresAndSkills(id, updatedStudent);
    }

    // 5. Delete a student record
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteStudent(@PathVariable Integer id) {
        service.deleteStudent(id);
        return ResponseEntity.ok(Map.of("message", "Student deleted successfully with ID: " + id));
    }

    // 6. Display merit list (average score: highest to lowest)
    @GetMapping("/merit-list")
    public List<Student> getMeritList() {
        return service.getMeritList();
    }
}
